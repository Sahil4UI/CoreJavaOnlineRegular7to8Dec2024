package com.example.students.dao;

import com.example.students.model.Student;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

// import com.example.students.model.Student;

public class StudentDAOImpl implements StudentDAO{
    private static final String URL = "jdbc:mysql://localhost:3306/studentdb";
    private static final String user = "root";
    private static final String PASSWORD = "";

    private Connection getConnection() throws SQLException{
        return DriverManager.getConnection(URL, user, PASSWORD);
    }

    @Override
    public void addStudent(Student student)
    {
            String query = "Insert into students (id,name,age,course) values (?,?,?,?)";
            try (Connection conn = getConnection(); 
                PreparedStatement stmt = conn.prepareStatement(query)
            )
            {
                stmt.setInt(1,student.getId());
                stmt.setString(2,student.getName());
                stmt.setInt(3,student.getAge());
                stmt.setString(4,student.getCourse());
                    stmt.executeUpdate();
            }catch(SQLException e){
                        e.printStackTrace();
            }
    }

    @Override
    public Student  getStudentById(int id)
    {
        String query = "Select * from students where id = ?";
        try (Connection conn = getConnection(); 
                PreparedStatement stmt = conn.prepareStatement(query)
            )
            {
               
                stmt.setInt(1,id);
                ResultSet rs = stmt.executeQuery();
                if(rs.next())
                {
                    return new Student(rs.getInt("id"), rs.getString("name"), rs.getInt("age"), rs.getString("course"));
                }


            }catch(SQLException e){
                        e.printStackTrace();
            }

            return null;
    }

    @Override
    public List<Student> getAllStudents()
    {
        List<Student> students = new ArrayList<>(); 
        String query = "Select * from students";
        try (Connection conn = getConnection(); 
                PreparedStatement stmt = conn.prepareStatement(query);
                ResultSet rs = stmt.executeQuery())
            {
                while (rs.next())
                {
                    students.add(new Student(rs.getInt("id"), rs.getString("name"), rs.getInt("age"), rs.getString("course")))   ;        
                }
                


            }catch(SQLException e){
                        e.printStackTrace();
            }

            return students;
    }

    @Override
    public void updateStudent(Student student)
    {
        String query = "UPDATE students SET name = ? , age = ? , course = ? where id = ?";
        try (Connection conn = getConnection(); 
        PreparedStatement stmt = conn.prepareStatement(query))
        {

            stmt.setString(1,student.getName());
            stmt.setInt(2,student.getAge());
            stmt.setString(3,student.getCourse());
            stmt.setInt(4,student.getId());
            stmt.executeUpdate();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteStudent(int id)
    {
        String query = "DELETE from students where id=?";
        try (Connection conn = getConnection(); 
        PreparedStatement stmt = conn.prepareStatement(query))
        {
            stmt.setInt(1, id);
            stmt.executeUpdate();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
}
