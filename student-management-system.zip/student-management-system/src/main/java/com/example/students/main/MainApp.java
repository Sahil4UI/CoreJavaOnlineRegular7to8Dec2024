package com.example.students.main;

import java.util.Scanner;

import com.example.students.dao.StudentDAO;
import com.example.students.dao.StudentDAOImpl;
import com.example.students.model.Student;

public class MainApp 
{
    public static void main( String[] args )
    {
        StudentDAO studentDAO = new StudentDAOImpl();
        Scanner  sc = new Scanner(System.in);

        while (true)
        {
            System.out.println("Press 1 to Add Student");
            System.out.println("Press 2 to Get Student by ID");
            System.out.println("Press 3 Get All Students");
            System.out.println("Press 4 to Update Student");
            System.out.println("Press 5 to Delete Student");
            System.out.println("Press 6 to EXIT");

            System.out.println("Enter Choice : ");
            int choice = sc.nextInt();


            switch (choice) {
                case 1: {
                    System.out.println("Enter ID : ");
                    int id = sc.nextInt();
                    System.out.println("Enter Name : ");
                    String name = sc.next();
                    System.out.println("Enter Age : ");
                    int age = sc.nextInt();
                    System.out.println("Enter Course : ");
                    String course = sc.next();
                    studentDAO.addStudent(new Student(id,name,age,course)); 
                    break;
                }
            case 2: {
                System.out.println("Enter ID : ");
                int id = sc.nextInt();
                System.out.println(studentDAO.getStudentById(id));
                break;
            }

            case 3: {
                studentDAO.getAllStudents().forEach(System.out::println);
                break;
            }

            case 4: {
                System.out.println("Enter ID : ");
                int id = sc.nextInt();
                System.out.println("Enter Name : ");
                String name = sc.next();
                System.out.println("Enter Age : ");
                int age = sc.nextInt();
                System.out.println("Enter Course : ");
                String course = sc.next();
                studentDAO.updateStudent(new Student(id,name,age,course));
                break;
            }

            case 5: {
                System.out.println("Enter ID : ");
                int id = sc.nextInt();
                studentDAO.deleteStudent(id);
                break;
            }
            case 6: {
                sc.close();
                System.exit(0);
                break;
            }

            default: {
                System.out.println("Invalid Choice");
                break;
            }

        }
    
    }
    }
}
